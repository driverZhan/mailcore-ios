#ifndef MAILCORE_MCSMTP_H

#define MAILCORE_MCSMTP_H

#include <MailCore/MCSMTPProgressCallback.h>
#include <MailCore/MCSMTPSession.h>

#endif
