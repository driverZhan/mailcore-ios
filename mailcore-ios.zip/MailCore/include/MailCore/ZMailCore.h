//
//  ZMailCore.h
//  ZMailCore
//
//  Created by .77 on 2024/7/17.
//

#import <Foundation/Foundation.h>

@interface ZMailCore : NSObject

@end
